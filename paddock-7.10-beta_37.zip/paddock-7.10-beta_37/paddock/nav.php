<? if(!defined("CONFIG")) exit() ?>
<? if(defined("USER_MUST_LOGIN") && !isset($login)) return; ?>
<ul>
<li class="head">Results</li>
<li><a href="?page=results">Results</a></li>
<? if(defined("USE_MYSQL") && defined("USE_LOGIN")) { ?>
<? if(!isset($login)) { ?>
<li class="head">Administration</li>
<li><a href="?page=login">Login</a></li>
<? } else { ?>
<li class="head">Race data</li>
<li><a href="?page=races">Races</a></li>
<li><a href="?page=seasons">Seasons</a></li>
<li><a href="?page=divisions">Divisions</a></li>
<li class="head">Team data</li>
<li><a href="?page=drivers">Drivers</a></li>
<li><a href="?page=teams">Teams</a></li>
<li class="head">Points</li>
<li><a href="?page=points">Rulesets</a></li>
<li class="head">Administration</li>
<li><a href="?page=users">Users</a></li>
<li><a href="?page=logout">Logout</a></li>
<? } ?>
<? } ?>
</ul>
