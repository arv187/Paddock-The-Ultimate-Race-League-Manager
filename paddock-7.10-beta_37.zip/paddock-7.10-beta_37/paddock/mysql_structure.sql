-- MySQL dump 10.11
--
-- Host: mysql1    Database: paddock
-- ------------------------------------------------------
-- Server version	5.0.32-Debian_7-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `division`
--

DROP TABLE IF EXISTS `division`;
CREATE TABLE `division` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `type` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `driver`
--

DROP TABLE IF EXISTS `driver`;
CREATE TABLE `driver` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `point_ruleset`
--

DROP TABLE IF EXISTS `point_ruleset`;
CREATE TABLE `point_ruleset` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `rp1` int(11) NOT NULL default '0',
  `rp2` int(11) NOT NULL default '0',
  `rp3` int(11) NOT NULL default '0',
  `rp4` int(11) NOT NULL default '0',
  `rp5` int(11) NOT NULL default '0',
  `rp6` int(11) NOT NULL default '0',
  `rp7` int(11) NOT NULL default '0',
  `rp8` int(11) NOT NULL default '0',
  `rp9` int(11) NOT NULL default '0',
  `rp10` int(11) NOT NULL default '0',
  `rp11` int(11) NOT NULL default '0',
  `rp12` int(11) NOT NULL default '0',
  `rp13` int(11) NOT NULL default '0',
  `rp14` int(11) NOT NULL default '0',
  `rp15` int(11) NOT NULL default '0',
  `qp1` int(11) NOT NULL default '0',
  `qp2` int(11) NOT NULL default '0',
  `qp3` int(11) NOT NULL default '0',
  `qp4` int(11) NOT NULL default '0',
  `qp5` int(11) NOT NULL default '0',
  `fl` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `race`
--

DROP TABLE IF EXISTS `race`;
CREATE TABLE `race` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  `track` varchar(30) NOT NULL default '',
  `laps` int(11) NOT NULL default '0',
  `season` int(11) NOT NULL default '0',
  `division` int(11) NOT NULL default '0',
  `ruleset` int(11) NOT NULL default '0',
  `ruleset_qualifying` int(11) NOT NULL default '0',
  `date` timestamp NOT NULL default '0000-00-00 00:00:00',
  `maxplayers` int(11) NOT NULL default '0',
  `result_official` tinyint(1) NOT NULL default '0',
  `progress` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `race_driver`
--

DROP TABLE IF EXISTS `race_driver`;
CREATE TABLE `race_driver` (
  `race` int(11) NOT NULL default '0',
  `team_driver` int(11) NOT NULL default '0',
  `grid` int(11) NOT NULL default '0',
  `position` int(11) NOT NULL default '0',
  `fastest_lap` tinyint(1) NOT NULL default '0',
  `laps` int(11) NOT NULL default '0',
  `time` int(11) NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  PRIMARY KEY  (`race`,`team_driver`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `season`
--

DROP TABLE IF EXISTS `season`;
CREATE TABLE `season` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL default '',
  `division` int(11) NOT NULL default '0',
  `ruleset` int(11) NOT NULL default '0',
  `ruleset_qualifying` int(11) NOT NULL default '0',
  `maxteams` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `season_team`
--

DROP TABLE IF EXISTS `season_team`;
CREATE TABLE `season_team` (
  `season` int(11) NOT NULL default '0',
  `team` int(11) NOT NULL default '0',
  PRIMARY KEY  (`season`,`team`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
CREATE TABLE `team` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `team_driver`
--

DROP TABLE IF EXISTS `team_driver`;
CREATE TABLE `team_driver` (
  `id` int(11) NOT NULL auto_increment,
  `team` int(11) NOT NULL default '0',
  `driver` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL default '',
  `passwd` varchar(40) NOT NULL default '',
  `active` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2007-10-01  9:06:43
