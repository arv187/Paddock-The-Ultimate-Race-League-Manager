<? if(!defined("CONFIG")) exit(); ?>
Welcome to the race administration for <a href="<?=$config['org_link']?>"><?=$config['org']?></a>.<br>
<br>
<div class="small">
Version <?=VERSION?><br>
</div>
