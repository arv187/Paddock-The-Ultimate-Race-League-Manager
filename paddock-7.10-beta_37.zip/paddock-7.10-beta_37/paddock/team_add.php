<? if(!defined("CONFIG")) exit(); ?>
<? if(!isset($login)) { show_error("You do not have administrator rights\n"); return; } ?>
<?
// Potential new drivers
$ndquery = "SELECT * FROM driver ORDER BY name ASC";
$ndresult = mysql_query($ndquery);
if(!$ndresult) {
	show_error("MySQL error: " . mysql_error() . "\n");
	return;
}

$drivers = array();
while($nditem = mysql_fetch_array($ndresult)) {
	$drivers[$nditem['id']] = $nditem['name'];
}

function show_driver_combo() {
	global $drivers;

	echo "<select name=\"driver[]\">\n";
	echo "<option value=\"\">&nbsp;</option>\n";
	foreach($drivers as $id => $driver) {
		echo "<option value=\"$id\">$driver</option>";
	}
	echo "</select>\n";
}
?>
<h1>Add team</h1>

<form action="team_add_do.php" method="post">
<table border="0">
<tr>
	<td width="120">Name:</td>
	<td><input type="text" name="name" maxlength="30"></td>
</tr>
<tr>
	<td width="120">Drivers:</td>
	<td>
		<? for($x = 0; $x < 5; $x++) {
		show_driver_combo();
		echo "<br>\n";
		} ?>
	</td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td>
		<input type="submit" class="button submit" value="Add">
		<input type="button" class="button cancel" value="Cancel" onclick="history.go(-1);">
	</td>
</tr>
</table>
</form>
